package com.cat.mylibrary_backed.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cat.mylibrary_backed.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
