package com.cat.mylibrary_backed.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cat.mylibrary_backed.entity.User;
import com.cat.mylibrary_backed.mapper.UserMapper;
import com.cat.mylibrary_backed.service.UserService;

public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}
