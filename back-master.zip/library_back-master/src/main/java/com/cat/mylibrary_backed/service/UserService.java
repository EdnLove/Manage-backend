package com.cat.mylibrary_backed.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cat.mylibrary_backed.entity.User;

public interface UserService extends IService<User> {
}
