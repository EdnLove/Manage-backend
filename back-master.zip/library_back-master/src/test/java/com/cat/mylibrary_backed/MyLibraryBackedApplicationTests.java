package com.cat.mylibrary_backed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyLibraryBackedApplicationTests {

    @Test
    void contextLoads() {
    }

}
